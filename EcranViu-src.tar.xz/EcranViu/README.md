# Ecran Viu (Android)

Aplicație Android 9+ în limba română: selectezi video/GIF local, alegi perioada de redare, alegi separat timpul de inactivitate de la stingerea ecranului și intervalul de așteptare până la redare, toate în format hh:mm:ss, apoi afișează conținutul fără sunet pe ecranul blocat, blochează ecranul la final și repetă. Atingerea videoclipului, deschiderea manuală a ecranului ori deblocarea suspendă ciclul până la următoarea stingere a ecranului.

## Compilare

Deschide acest proiect în Android Studio (JDK17), lasă Gradle să sincronizeze, apoi **Build > Build APK(s)**. APK-ul apare în `app/build/outputs/apk/debug/app-debug.apk`.

Alternativ, în GitHub Actions rulează `Build Android APK` și descarcă arhiva artifact `EcranViu-debug-APK`.

## Configurare și permisiuni

1. Alege un clip video sau GIF. Se folosește numai accesul la fișierul ales, nu întreaga galerie.
2. Activează Administrator dispozitiv (pentru `lockNow()`). Dezactivează-l din setările Android dacă vrei să dezinstalezi aplicația.
3. Activează alarme exacte, afișarea peste alte aplicații, notificările și permisiunea de notificări pe întreg ecranul, acolo unde sunt disponibile.
4. În telefonul Samsung, poți seta aplicația la baterie **Fără restricții**, pentru a reduce riscul de oprire a serviciului.
5. Apasă **Pornește automatizarea** apoi stinge ecranul. Un serviciu de prim-plan păstrează monitorizarea activă.

## Limitări Android

**Nu e garantat că aplicația va deschide singură ecranul pe toate telefoanele.** Android 10+ limitează pornirea de activități din fundal. Android 14+ restricționează permisiunea de notificări pe întregul ecran la cazurile acceptate și poate cere intervenția utilizatorului. Unele ROM-uri au politici suplimentare de economie a bateriei. Aplicația nu dezactivează PIN-ul/amprenta și nu ocolește ecranul securizat. Fără permisiunea de alarmă exactă, declanșarea poate fi întârziată de Doze.

**Definiția inactivității:** pornirea ciclului are loc după stingerea ecranului, nu după fiecare atingere în orice aplicație. Nu este urmărită activitatea utilizatorului în alte aplicații.

## Note

- Pentru clipuri video, „toată durata” înseamnă o redare. Pentru GIF, opțiunea „un ciclu GIF” redă animația exact o dată, folosind notificarea de final a sistemului Android, fără cronometru estimativ.
- Sunetul nu este redat (`MediaPlayer#setVolume(0,0)`).
- Pentru instalare directă în afara Google Play, utilizatorul poate avea nevoie să permită instalarea din surse necunoscute.
- Acesta este un prototip, nu o aplicație testată pe toate modelele sau distribuită în Play Store.

## Versiunea 1.3: temporizări personalizate

- Inactivitate de la stingerea ecranului: hh/mm/ss, implicit 00:01:00.
- Așteptare după inactivitate: minim hh/mm/ss (implicit 00:05:00) și maxim hh/mm/ss (implicit 00:10:00).
- Toate cele trei câmpuri acceptă 00:00:00. Dacă minimul este egal cu maximul, așteptarea este fixă; altfel se alege aleatoriu la fiecare ciclu.
- Timpii sunt salvați când se apasă „Pornește automatizarea” și persista după repornirea aplicației. Versiunea nouă păstrează pauzele vechi salvate în minute.
- Totalul programat = inactivitate + așteptare aleasă. Android poate întârzia alarma, mai ales fără permisiunea de alarme exacte ori în modul Doze.
