package ro.ecranviu;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (MonitorService.instance != null) MonitorService.instance.triggerPlayback();
    }
}
