package ro.ecranviu;
import android.app.admin.DeviceAdminReceiver;
public class AdminReceiver extends DeviceAdminReceiver { }
