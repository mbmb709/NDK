package ro.ecranviu;

import android.app.*;
import android.app.admin.DevicePolicyManager;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import java.util.Random;
import java.util.Locale;

public class MonitorService extends Service {
    public static final String ACTION_START="ro.ecranviu.START";
    public static final String ACTION_STOP="ro.ecranviu.STOP";
    public static final String ACTION_PLAY_DONE="ro.ecranviu.PLAY_DONE";
    public static final String ACTION_USED="ro.ecranviu.USED";
    public static MonitorService instance;
    private static final String CHANNEL="idle_media";
    private final Random random = new Random();
    private AlarmManager alarms;
    private PendingIntent alarmIntent;
    private BroadcastReceiver screens;
    private boolean showing=false;
    private boolean waking=false;
    private SharedPreferences prefs;

    @Override public void onCreate(){
        super.onCreate();instance=this;
        prefs=getSharedPreferences("config",MODE_PRIVATE);
        alarms=(AlarmManager)getSystemService(ALARM_SERVICE);
        Intent trigger=new Intent(this,AlarmReceiver.class);
        alarmIntent=PendingIntent.getBroadcast(this,81,trigger,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        IntentFilter f=new IntentFilter();f.addAction(Intent.ACTION_SCREEN_OFF);f.addAction(Intent.ACTION_SCREEN_ON);f.addAction(Intent.ACTION_USER_PRESENT);
        screens=new BroadcastReceiver(){
            @Override public void onReceive(Context ctx,Intent i){
                String action=i.getAction();
                if(Intent.ACTION_USER_PRESENT.equals(action)){cancel();showing=false;waking=false;}
                else if(Intent.ACTION_SCREEN_ON.equals(action)){if(!waking){cancel();showing=false;}}
                else if(Intent.ACTION_SCREEN_OFF.equals(action)){waking=false;showing=false;schedule();}
            }
        };
        registerReceiver(screens,f);
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel=new NotificationChannel(CHANNEL,"Ecran Viu",NotificationManager.IMPORTANCE_HIGH);
        channel.setSound(null,null);channel.enableVibration(false);nm.createNotificationChannel(channel);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?ACTION_START:intent.getAction();
        if(ACTION_STOP.equals(action)){
            cancel();prefs.edit().putBoolean("enabled",false).apply();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;
        }
        if(ACTION_USED.equals(action)){cancel();showing=false;waking=false;return START_STICKY;}
        if(ACTION_PLAY_DONE.equals(action)){
            showing=false;waking=false;
            // Repetă numai după ce ecranul a fost stins prin Device Admin.
            cancel();
            DevicePolicyManager dpm=(DevicePolicyManager)getSystemService(DEVICE_POLICY_SERVICE);
            ComponentName admin=new ComponentName(this,AdminReceiver.class);
            if(dpm.isAdminActive(admin)) {try {dpm.lockNow();}catch(Exception ignored){}}
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(!pm.isInteractive())schedule();
            return START_STICKY;
        }
        startForeground(19,buildNotification(false));
        if(prefs.getBoolean("enabled",false)){
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(!pm.isInteractive())schedule();
        }
        return START_STICKY;
    }
    private Notification buildNotification(boolean play){
        Intent main=new Intent(this,MainActivity.class);
        PendingIntent launch=PendingIntent.getActivity(this,3,main,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=new Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(play?"Ecran Viu: redare":"Ecran Viu: automatizare activă")
            .setContentText(play?"Se redă clipul fără sunet":describeDelays())
            .setContentIntent(launch).setOngoing(!play).setAutoCancel(play)
            .setCategory(play?Notification.CATEGORY_ALARM:Notification.CATEGORY_SERVICE);
        if(play){
            Intent player=new Intent(this,PlaybackActivity.class);
            player.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent full=PendingIntent.getActivity(this,4,player,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            b.setFullScreenIntent(full,true);
        }
        return b.build();
    }
    private String describeDelays() {
        long idle=Math.max(0L,prefs.getLong("idleSeconds",60L));
        long low=Math.max(0L,prefs.getLong("waitMinSeconds",prefs.getInt("minDelay",5)*60L));
        long high=Math.max(0L,prefs.getLong("waitMaxSeconds",prefs.getInt("maxDelay",10)*60L));
        return "Inactivitate "+hhmmss(idle)+"; pauză "+hhmmss(low)+"–"+hhmmss(high);
    }
    private static String hhmmss(long seconds) {
        return String.format(Locale.ROOT,"%02d:%02d:%02d",seconds/3600,(seconds/60)%60,seconds%60);
    }
    private void cancel(){alarms.cancel(alarmIntent);}
    private void schedule(){
        if(!prefs.getBoolean("enabled",false))return;
        cancel();
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        if(pm.isInteractive())return;
        long idle=Math.max(0L,prefs.getLong("idleSeconds",60L));
        long min=Math.max(0L,prefs.getLong("waitMinSeconds",prefs.getInt("minDelay",5)*60L));
        long max=Math.max(min,prefs.getLong("waitMaxSeconds",prefs.getInt("maxDelay",10)*60L));
        // Alege în secunde, inclusiv ambele capete; 0 secunde este valid.
        long randomWait=min+(max==min?0L:(long)(random.nextDouble()*(max-min+1L)));
        long delay=(idle+randomWait)*1000L;
        long when=SystemClock.elapsedRealtime()+delay;
        try {
            if(Build.VERSION.SDK_INT>=31 && !alarms.canScheduleExactAlarms())
                alarms.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,when,alarmIntent);
            else alarms.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,when,alarmIntent);
        } catch(Exception e){alarms.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,when,alarmIntent);}
    }
    public void triggerPlayback(){
        if(!prefs.getBoolean("enabled",false) || showing)return;
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        if(pm.isInteractive())return;
        showing=true;waking=true;
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(21,buildNotification(true));
        // Android 10+ poate bloca startActivity din background. Notificarea cu
        // full-screen intent este calea recomandată, dacă utilizatorul o permite.
        try {
            Intent i=new Intent(this,PlaybackActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        }catch(Exception ignored){}
        new Handler(Looper.getMainLooper()).postDelayed(()->{
            if(showing && !pm.isInteractive()) { showing=false;waking=false; }
        },10000);
    }
    @Override public void onDestroy(){cancel();if(screens!=null)unregisterReceiver(screens);instance=null;super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
