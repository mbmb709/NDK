package ro.ecranviu;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 11;
    private SharedPreferences prefs;
    private TextView selected, state;
    private Spinner duration;
    private EditText minimum, maximum;

    @Override public void onCreate(Bundle stateBundle) {
        super.onCreate(stateBundle);
        prefs = getSharedPreferences("config", MODE_PRIVATE);
        buildUi();
    }

    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.rgb(235,242,252)); t.setTextSize(size);
        t.setPadding(0,dp(7),0,dp(7));
        return t;
    }
    private Button button(String s, LinearLayout parent, View.OnClickListener onClick) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(onClick);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0,dp(4),0,dp(4)); parent.addView(b,lp); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(12,19,33));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(30),dp(22),dp(30)); scroll.addView(root);
        TextView heading = text("ECRAN VIU  ✦", 29); heading.setTypeface(null, Typeface.BOLD); root.addView(heading);
        root.addView(text("Video sau GIF pe ecranul blocat, fără sunet.",15));
        selected = text(mediaLabel(),14); root.addView(selected);
        button("Alege video / GIF din telefon",root,v -> selectMedia());
        root.addView(text("Cât timp se redă",17));
        duration = new Spinner(this);
        String[] entries = {"5 secunde", "10 secunde", "15 secunde", "30 secunde", "60 de secunde", "Toată durata video-ului / un ciclu GIF"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,entries);
        duration.setAdapter(adapter); duration.setSelection(prefs.getInt("durationPos",1)); root.addView(duration);
        root.addView(text("Pauză aleatorie după primul minut de inactivitate",16));
        root.addView(text("Interval în minute (minim / maxim)",13));
        LinearLayout times = new LinearLayout(this); times.setOrientation(LinearLayout.HORIZONTAL);
        minimum = new EditText(this); maximum = new EditText(this);
        for (EditText e : new EditText[]{minimum,maximum}) {
            e.setInputType(2);e.setTextColor(Color.WHITE);e.setSingleLine(true);
            times.addView(e,new LinearLayout.LayoutParams(0,dp(55),1));
        }
        minimum.setHint("min");maximum.setHint("max");
        minimum.setText(String.valueOf(prefs.getInt("minDelay",5)));
        maximum.setText(String.valueOf(prefs.getInt("maxDelay",10)));
        root.addView(times);
        root.addView(text("Permisiuni necesare (activează-le o singură dată)",16));
        button("1. Activează permisiunea de blocare a ecranului",root,v -> {
            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,new ComponentName(this,AdminReceiver.class));
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"Aplicația blochează ecranul după redare.");startActivity(i);
        });
        button("2. Permite pornirea alarmelor exacte",root,v -> {
            if(Build.VERSION.SDK_INT>=31) { try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName()))); }
            catch(Exception e){ toast("Deschide setările de alarme ale aplicației."); }} else toast("Permisiunea nu e necesară pe acest Android.");
        });
        button("3. Permite afișarea peste alte aplicații",root,v ->
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
        if(Build.VERSION.SDK_INT>=34) button("4. Permite notificări pe întregul ecran",root,v -> {
            try {startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName())));}
            catch(Exception e){toast("Nu există această setare pe telefon.");}
        });
        if(Build.VERSION.SDK_INT>=33) button("5. Permite notificări",root,v -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},50));
        button("▶ PORNEȘTE automatizarea",root,v -> startMonitoring());
        button("■ OPREȘTE automatizarea",root,v -> {
            prefs.edit().putBoolean("enabled",false).apply();
            Intent i=new Intent(this,MonitorService.class);i.setAction(MonitorService.ACTION_STOP);startService(i);
            updateStatus();
        });
        state = text("",15);root.addView(state);
        root.addView(text("O atingere în timpul redării o oprește. Deblocarea sau aprinderea manuală a ecranului suspendă ciclul până când ecranul se stinge din nou. Android poate limita trezirea în fundal.",13));
        setContentView(scroll); updateStatus();
    }
    private String mediaLabel(){return prefs.getString("uri","").isEmpty()?"Niciun fișier ales":"Fișier ales: "+prefs.getString("name","media");}
    private void selectMedia(){
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/gif","video/*"});
        startActivityForResult(i,PICK_MEDIA);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PICK_MEDIA && result==RESULT_OK && data!=null && data.getData()!=null){
            Uri uri=data.getData();
            try {getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            String name=uri.getLastPathSegment(); if(name==null)name="media";
            prefs.edit().putString("uri",uri.toString()).putString("name",name).apply();selected.setText(mediaLabel());
        }
    }
    private int minutes(EditText field,int fallback){
        try {return Math.min(180,Math.max(1,Integer.parseInt(field.getText().toString().trim())));}catch(Exception e){return fallback;}
    }
    private void startMonitoring(){
        if(prefs.getString("uri","").isEmpty()){toast("Alege mai întâi un video sau GIF.");return;}
        DevicePolicyManager dpm=(DevicePolicyManager)getSystemService(DEVICE_POLICY_SERVICE);
        if(!dpm.isAdminActive(new ComponentName(this,AdminReceiver.class))){toast("Activează mai întâi blocarea ecranului (pasul 1).");return;}
        int min=minutes(minimum,5),max=minutes(maximum,10);
        if(max<min){int t=min;min=max;max=t;}
        prefs.edit().putInt("durationPos",duration.getSelectedItemPosition()).putInt("minDelay",min).putInt("maxDelay",max).putBoolean("enabled",true).apply();
        Intent i=new Intent(this,MonitorService.class);i.setAction(MonitorService.ACTION_START);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i); else startService(i);
        toast("Pornit. Stinge ecranul pentru a porni ciclul.");updateStatus();
    }
    private void updateStatus(){if(state!=null)state.setText(prefs.getBoolean("enabled",false)?"● Activ: așteaptă stingerea ecranului":"○ Oprit");}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume();if(state!=null)updateStatus();}
}
