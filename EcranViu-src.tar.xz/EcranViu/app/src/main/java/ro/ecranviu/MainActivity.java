package ro.ecranviu;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import java.util.Locale;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 11;
    private SharedPreferences prefs;
    private TextView selected, state;
    private Spinner duration;
    private EditText[] inactivityTime, minimumWaitTime, maximumWaitTime;

    @Override public void onCreate(Bundle stateBundle) {
        super.onCreate(stateBundle);
        prefs = getSharedPreferences("config", MODE_PRIVATE);
        buildUi();
    }

    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.rgb(235,242,252)); t.setTextSize(size);
        t.setPadding(0,dp(7),0,dp(7));
        return t;
    }
    private Button button(String s, LinearLayout parent, View.OnClickListener onClick) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(onClick);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0,dp(4),0,dp(4)); parent.addView(b,lp); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(12,19,33));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(30),dp(22),dp(30)); scroll.addView(root);
        TextView heading = text("ECRAN VIU  ✦", 29); heading.setTypeface(null, Typeface.BOLD); root.addView(heading);
        root.addView(text("Video sau GIF pe ecranul blocat, fără sunet.",15));
        selected = text(mediaLabel(),14); root.addView(selected);
        button("Alege video / GIF din telefon",root,v -> selectMedia());
        root.addView(text("Cât timp se redă",17));
        duration = new Spinner(this);
        String[] entries = {"5 secunde", "10 secunde", "15 secunde", "30 secunde", "60 de secunde", "Toată durata video-ului / un ciclu GIF"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,entries);
        duration.setAdapter(adapter); duration.setSelection(prefs.getInt("durationPos",1)); root.addView(duration);
        root.addView(text("1. Inactivitate după stingerea ecranului",17));
        root.addView(text("După ce se stinge ecranul, așteaptă această perioadă înainte să înceapă timpul până la redare.",13));
        inactivityTime = addTimeInputs(root, prefs.getLong("idleSeconds",60L));

        root.addView(text("2. Așteptare după inactivitate",17));
        root.addView(text("Introdu intervalul minim și maxim în ore, minute și secunde. Dacă sunt egale, pauza este fixă; altfel se alege aleatoriu o valoare din interval.",13));
        root.addView(text("Așteptare minimă",15));
        long storedMinimum = prefs.contains("waitMinSeconds") ? prefs.getLong("waitMinSeconds",300L)
            : prefs.getInt("minDelay",5)*60L;
        minimumWaitTime = addTimeInputs(root,storedMinimum);
        root.addView(text("Așteptare maximă",15));
        long storedMaximum = prefs.contains("waitMaxSeconds") ? prefs.getLong("waitMaxSeconds",600L)
            : prefs.getInt("maxDelay",10)*60L;
        maximumWaitTime = addTimeInputs(root,storedMaximum);
        root.addView(text("Format: hh : mm : ss. Valoarea 00 este permisă în orice câmp, inclusiv 00:00:00. Limite: ore 0–999, minute și secunde 0–59.",13));
        root.addView(text("Permisiuni necesare (activează-le o singură dată)",16));
        button("1. Activează permisiunea de blocare a ecranului",root,v -> {
            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,new ComponentName(this,AdminReceiver.class));
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"Aplicația blochează ecranul după redare.");startActivity(i);
        });
        button("2. Permite pornirea alarmelor exacte",root,v -> {
            if(Build.VERSION.SDK_INT>=31) { try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName()))); }
            catch(Exception e){ toast("Deschide setările de alarme ale aplicației."); }} else toast("Permisiunea nu e necesară pe acest Android.");
        });
        button("3. Permite afișarea peste alte aplicații",root,v ->
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
        if(Build.VERSION.SDK_INT>=34) button("4. Permite notificări pe întregul ecran",root,v -> {
            try {startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName())));}
            catch(Exception e){toast("Nu există această setare pe telefon.");}
        });
        if(Build.VERSION.SDK_INT>=33) button("5. Permite notificări",root,v -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},50));
        button("▶ PORNEȘTE automatizarea",root,v -> startMonitoring());
        button("■ OPREȘTE automatizarea",root,v -> {
            prefs.edit().putBoolean("enabled",false).apply();
            Intent i=new Intent(this,MonitorService.class);i.setAction(MonitorService.ACTION_STOP);startService(i);
            updateStatus();
        });
        state = text("",15);root.addView(state);
        root.addView(text("O atingere în timpul redării o oprește. Deblocarea sau aprinderea manuală a ecranului suspendă ciclul până când ecranul se stinge din nou. Android poate limita trezirea în fundal.",13));
        setContentView(scroll); updateStatus();
    }
    private String mediaLabel(){return prefs.getString("uri","").isEmpty()?"Niciun fișier ales":"Fișier ales: "+prefs.getString("name","media");}
    private void selectMedia(){
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/gif","video/*"});
        startActivityForResult(i,PICK_MEDIA);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PICK_MEDIA && result==RESULT_OK && data!=null && data.getData()!=null){
            Uri uri=data.getData();
            try {getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            String name=uri.getLastPathSegment(); if(name==null)name="media";
            prefs.edit().putString("uri",uri.toString()).putString("name",name).apply();selected.setText(mediaLabel());
        }
    }
    private EditText[] addTimeInputs(LinearLayout root, long totalSeconds) {
        long h = totalSeconds/3600;
        long m = (totalSeconds%3600)/60;
        long sec = totalSeconds%60;
        String[] labels={"hh (ore)","mm (minute)","ss (secunde)"};
        long[] values={h,m,sec};
        LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);
        EditText[] fields=new EditText[3];
        for(int i=0;i<3;i++) {
            LinearLayout column=new LinearLayout(this);
            column.setOrientation(LinearLayout.VERTICAL);
            TextView cap=text(labels[i],12);
            cap.setGravity(Gravity.CENTER);
            column.addView(cap);
            EditText e=new EditText(this);
            e.setInputType(InputType.TYPE_CLASS_NUMBER);
            e.setSelectAllOnFocus(true);
            e.setSingleLine(true);
            e.setTextColor(Color.WHITE);
            e.setHintTextColor(Color.LTGRAY);
            e.setGravity(Gravity.CENTER);
            e.setTextSize(21);
            e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(i==0?3:2)});
            e.setText(String.format(Locale.ROOT,"%02d",values[i]));
            e.setContentDescription(labels[i]);
            column.addView(e,new LinearLayout.LayoutParams(-1,dp(56)));
            line.addView(column,new LinearLayout.LayoutParams(0,-2,1f));
            fields[i]=e;
        }
        root.addView(line);
        return fields;
    }
    private long getTimeInSeconds(EditText[] fields) {
        long[] vals = new long[3];
        int[] caps = {999,59,59};
        for(int i=0;i<3;i++) {
            String value=fields[i].getText().toString().trim();
            if(value.isEmpty()) value="0";
            try { vals[i]=Long.parseLong(value); }
            catch(NumberFormatException e) { throw new IllegalArgumentException("Folosește doar cifre în câmpurile de timp."); }
            if(vals[i]<0 || vals[i]>caps[i])
                throw new IllegalArgumentException("Orele pot fi 0–999; minutele și secundele 0–59.");
        }
        return vals[0]*3600L+vals[1]*60L+vals[2];
    }
    private void startMonitoring(){
        if(prefs.getString("uri","").isEmpty()){toast("Alege mai întâi un video sau GIF.");return;}
        DevicePolicyManager dpm=(DevicePolicyManager)getSystemService(DEVICE_POLICY_SERVICE);
        if(!dpm.isAdminActive(new ComponentName(this,AdminReceiver.class))){toast("Activează mai întâi blocarea ecranului (pasul 1).");return;}
        long idle, minWait, maxWait;
        try {
            idle = getTimeInSeconds(inactivityTime);
            minWait = getTimeInSeconds(minimumWaitTime);
            maxWait = getTimeInSeconds(maximumWaitTime);
        } catch(IllegalArgumentException e) { toast(e.getMessage()); return; }
        if(maxWait<minWait) { long t=minWait;minWait=maxWait;maxWait=t; }
        prefs.edit()
            .putInt("durationPos",duration.getSelectedItemPosition())
            .putLong("idleSeconds",idle)
            .putLong("waitMinSeconds",minWait)
            .putLong("waitMaxSeconds",maxWait)
            .putBoolean("enabled",true).apply();
        Intent i=new Intent(this,MonitorService.class);i.setAction(MonitorService.ACTION_START);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i); else startService(i);
        toast("Pornit. Stinge ecranul pentru a porni ciclul.");updateStatus();
    }
    private void updateStatus(){if(state!=null)state.setText(prefs.getBoolean("enabled",false)?"● Activ: așteaptă stingerea ecranului":"○ Oprit");}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume();if(state!=null)updateStatus();}
}
