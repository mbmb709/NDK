package ro.ecranviu;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Movie;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.InputStream;

public class PlaybackActivity extends Activity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private AnimatedImageDrawable animated;
    private boolean completed=false, started=false;
    private final Runnable endRunnable=()->finishPlayback(true);
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        setShowWhenLocked(true);setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);
        root.setOnTouchListener((view,event)->{if(event.getAction()==MotionEvent.ACTION_DOWN){finishPlayback(false);return true;}return true;});
        setContentView(root);
        String source=getSharedPreferences("config",MODE_PRIVATE).getString("uri","");
        if(source.isEmpty()){finishPlayback(false);return;}
        Uri uri=Uri.parse(source);
        int index=getSharedPreferences("config",MODE_PRIVATE).getInt("durationPos",1);
        int[] seconds={5,10,15,30,60,-1};
        final int time=seconds[Math.min(Math.max(index,0),seconds.length-1)];
        String mime=getContentResolver().getType(uri);
        boolean gif=(mime!=null&&mime.equalsIgnoreCase("image/gif")) || uri.toString().toLowerCase().contains(".gif");
        if(gif){
            try {
                ImageDecoder.Source image=ImageDecoder.createSource(getContentResolver(),uri);
                Drawable drawable=ImageDecoder.decodeDrawable(image);
                ImageView view=new ImageView(this);view.setImageDrawable(drawable);view.setScaleType(ImageView.ScaleType.FIT_CENTER);
                root.addView(view,new FrameLayout.LayoutParams(-1,-1));
                view.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){finishPlayback(false);return true;}return true;});
                if(drawable instanceof AnimatedImageDrawable){animated=(AnimatedImageDrawable)drawable;animated.setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);animated.start();}
                long limit=(time>0?time*1000L:gifDuration(uri));
                started=true;handler.postDelayed(endRunnable,Math.max(100L,limit));
            }catch(Exception e){displayError(root,"GIF indisponibil: "+e.getMessage());}
        }else{
            SurfaceView surface=new SurfaceView(this);root.addView(surface,new FrameLayout.LayoutParams(-1,-1));
            surface.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){finishPlayback(false);return true;}return true;});
            surface.getHolder().addCallback(new SurfaceHolder.Callback(){
                public void surfaceCreated(SurfaceHolder h){
                    if(completed)return;
                    try {
                        player=new MediaPlayer();player.setDataSource(PlaybackActivity.this,uri);
                        player.setDisplay(h);player.setVolume(0f,0f);
                        player.setLooping(time>0);
                        player.setOnPreparedListener(p->{if(completed)return;started=true;p.start();
                            if(time>0)handler.postDelayed(endRunnable,time*1000L);
                        });
                        player.setOnCompletionListener(p->{if(time<0)finishPlayback(true);});
                        player.setOnErrorListener((p,what,extra)->{displayError(root,"Video-ul nu poate fi redat.");return true;});
                        player.prepareAsync();
                    }catch(Exception e){displayError(root,"Eroare la deschiderea video-ului.");}
                }
                public void surfaceChanged(SurfaceHolder h,int f,int w,int z){}
                public void surfaceDestroyed(SurfaceHolder h){}
            });
        }
    }
    private long gifDuration(Uri uri){
        try(InputStream s=getContentResolver().openInputStream(uri)){
            Movie m=Movie.decodeStream(s);if(m!=null&&m.duration()>0)return m.duration();
        }catch(Exception ignored){}
        return 5000L;
    }
    private void displayError(FrameLayout root,String msg){
        TextView t=new TextView(this);t.setText(msg+"\nAtinge ecranul pentru a ieși.");t.setTextColor(Color.WHITE);t.setTextSize(18);
        t.setPadding(40,100,40,20);root.addView(t);
        t.setOnClickListener(v->finishPlayback(false));
    }
    private void finishPlayback(boolean byTimer){
        if(completed)return;completed=true;
        handler.removeCallbacks(endRunnable);
        if(animated!=null)animated.stop();
        if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}
        if(MonitorService.instance!=null){
            android.content.Intent i=new android.content.Intent(this,MonitorService.class);
            i.setAction(byTimer?MonitorService.ACTION_PLAY_DONE:MonitorService.ACTION_USED);
            startService(i);
        }
        finish();
    }
    @Override public void onBackPressed(){finishPlayback(false);}
    @Override protected void onDestroy(){handler.removeCallbacks(endRunnable);if(player!=null){player.release();player=null;}if(animated!=null)animated.stop();super.onDestroy();}
}
