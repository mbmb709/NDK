# Image & Schematic Editor (Geode v5.11.2 / GD 2.2081)

This is an **uncompiled, unverified C++ source prototype**, not a ready-to-install `.geode`.

Targets Windows 64-bit, Android ARM32 and ARM64. Features: editor IMG button, image picker with name, visual overlay drag, decorative pixel-art object generation (<=48x48), and custom GDSCHEM1 schematic save/load. Does not open Minecraft schematics.

For a potential cross-platform `.geode` build, push this project to GitHub and run the included GitHub Actions workflow. Native SDK integration still needs testing and may fail. See `README_RO.md` for detailed instructions.
