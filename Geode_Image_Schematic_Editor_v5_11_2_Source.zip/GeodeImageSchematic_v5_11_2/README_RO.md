# Image & Schematic Editor – Geode 5.11.2 (versiunea anterioară stabilă)

**Geometry Dash:** 2.2081  
**Sisteme:** Windows 64-bit, Android ARM64 și ARM32  
**Stadiu:** cod sursă adaptat pentru Geode v5.11.2; NU reprezintă un fișier `.geode` compilat și testat.

## Funcționalități implementate în sursă

- Buton **IMG** în editor, cu fereastra **Import an Image / Browse Schematics**.
- Selectare imagine PNG/JPG; afișare nume + extensie.
- **Import**: imagine vizuală semi-transparentă cu drag/touch, care nu se salvează ca obiect în level.
- **Import Recommended Objects**: fotografie redusă la cel mult 48×48 puncte, convertită în obiecte GD decorative de tip pixel. Nu este încă optimizare inteligentă cu linii/poligoane.
- **Download .schem**, **Make a Schematic**, **Browse Schematics**: format propriu GDSCHEM1 pentru obiectele Geometry Dash; nu este format Minecraft.

## Compilare online (fără SDK pe calculator)

1. Pune **conținutul** acestui proiect într-un repository GitHub.
2. Intră la `Actions` > `Build Geode v5.11.2 (Geometry Dash 2.2081)` > `Run workflow`.
3. Dacă toate cele trei compilări reușesc, deschide jobul `package` și descarcă artefactul `ImageSchematicEditor-Geode-v5.11.2`.
4. Arhiva rezultată ar trebui să conțină un singur `.geode` pentru Windows și Android.

Workflow-ul folosește `geode-sdk/build-geode-mod` cu SDK **v5.11.2**. Codul de integrare cu jocul **nu a putut fi compilat aici** pentru că lipsesc SDK-ul, Android NDK și toolchainul Windows. Pot apărea erori la compilare, pe care trebuie să le arate logul GitHub Actions; acest workflow nu garantează un `.geode` funcțional.

## Compilare locală

Instalează Geode CLI, Geode SDK v5.11.2, toolchainurile Windows și Android NDK, apoi din rădăcina proiectului:

```bash
geode build -p windows --config Release
geode build -p android64 --config Release
geode build -p android32 --config Release
```

Comenzile depind de platforma-gazdă și configurarea Geode CLI. Poți folosi și workflow-ul GitHub Actions de mai sus.

## Teste fără Geode

```bash
./tests/run-core.sh
```

Sunt teste doar pentru conversia de pixeli și formatul `.schem`, nu pentru integrarea modului cu jocul.

## Observații

Android poate afișa un selector de fișiere în locul galeriei foto. Unele fișiere Android selectate prin provider (URI `content://`) pot avea nevoie de copierea în directorul intern înainte de încărcare; acest suport nu este încă verificat. Salvarea în Downloads depinde de selectorul Android. Testează pe un nivel de probă înainte de a importa obiecte în leveluri importante.
